import { print,filename } from "./display.js";
console.log(print());
console.log(filename);