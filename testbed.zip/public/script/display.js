export const  filename="display.js"
export function print()
{
    return "This External file will be displyed in main file";
}