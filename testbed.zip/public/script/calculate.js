//let sum=0;
var output=0;
for(var i=0;i<100000000;i++)
{
     output=i;
    postMessage(output);
}