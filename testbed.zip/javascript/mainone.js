
        document.write("Embed Javascript Inside JavascriptFile");
        var script=document.createElement("script");
        script.src="embedjs.js";
        document.head.appendChild(script);


    